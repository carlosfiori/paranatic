@extends('app')

@section('titulopagina')
    Inicial
@endsection



@section('titulomenor')
    <!-- <h1>Dashboard 	<small>Control panel</small>	</h1> -->
@endsection


@section('valortotal')
    <footer class="main-footer" style="text-align: center; padding: 0;">
        <div>
            <span style="font-size: 1.6em;">SALDO</span>
            <br>
            <span style="font-size: 2em;font-weight: bold">
        <b>R$</b> 300
        </span>
        </div>
        <hr>
        <div class="flex-saldo">
            <div>
                <a href="/extrato">
                    <i class="fa fa-history" aria-hidden="true"></i>
                    EXTRATO</a>
            </div>
            <div>
                <a href="/mais"><i class="fa fa-plus-circle" aria-hidden="true"></i></a>
            </div>
        </div>
    </footer>
@endsection



@section('content')

    <style>
        .flex-saldo {
            display: flex;
            justify-content: space-around;
        }

        .flex-saldo div {
            width: 50%;
            font-size: 2em;
        }

        .flex-saldo a {
            color: #999;
        }
    </style>


    <div class="row">
        <div class="col-md-12">
            <div class="novo">
                <a href="/novo" class="btn btn-success pull-right">Nova Fatura</a>
            </div>

        </div>
    </div>



@endsection


