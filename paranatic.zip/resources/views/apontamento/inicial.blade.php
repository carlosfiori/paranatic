@extends('app')

@section('titulopagina')
	Inicial
@endsection



@section('titulomenor')
	<h1>Dashboard 	<small>Control panel</small>	</h1>
@endsection


@section('content')
asd
<div class="row">
		

	<table class="table table-bordered">
		<thead>
			<tr>
				<th>id</th>
				<th>Nome</th>
				<th>Dia</th>
				<th>Horas</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<th>asd</th>
				<th></th>
				<th></th>
			</tr>
			<tr>
				<th>asd</th>
				<th>asd</th>
				<th></th>
			</tr>
			<tr>
				<th></th>
				<th></th>
				<th></th>
			</tr>
		</tbody>
	</table>


</div>


@endsection



 