@extends('app')

@section('titulopagina')
	Inicial
@endsection



@section('titulomenor')
	<!-- <h1>Dashboard 	<small>Control panel</small>	</h1> -->
@endsection


@section('content')

<div class="row">
	<!-- <h1>ola mundo</h1> -->
</div>


@endsection



 